import 'package:flutter/material.dart';

import '../screens/splash/splash_screen.dart';
import '../screens/login/login_screen.dart';
import '../screens/dashboard/dashboard_screen.dart';

import '../screens/patients/patients_screen.dart';
import '../screens/patients/add_patient_screen.dart';
import '../screens/patients/edit_patient_screen.dart';
import '../screens/patients/patient_details_screen.dart';

class AppRoutes {
  static const String splash = '/';

  static const String login = '/login';

  static const String dashboard =
      '/dashboard';

  static const String patients =
      '/patients';

  static const String addPatient =
      '/add-patient';

  static const String editPatient =
      '/edit-patient';

  static const String patientDetails =
      '/patient-details';

  static Map<String, WidgetBuilder>
      get routes {
    return {
      splash: (context) =>
          const SplashScreen(),

      login: (context) =>
          const LoginScreen(),

      dashboard: (context) =>
          const DashboardScreen(),

      patients: (context) =>
          const PatientsScreen(),

      addPatient: (context) =>
          const AddPatientScreen(),

      editPatient: (context) {
        final id =
            ModalRoute.of(context)!
                .settings
                .arguments as int;

        return EditPatientScreen(
          patientId: id,
        );
      },

      patientDetails: (context) {
        final id =
            ModalRoute.of(context)!
                .settings
                .arguments as int;

        return PatientDetailsScreen(
          patientId: id,
        );
      },
    };
  }
}