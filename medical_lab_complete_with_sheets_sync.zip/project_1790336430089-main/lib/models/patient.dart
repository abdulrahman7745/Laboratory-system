class Patient {
  final int? id;
  final String patientNumber;
  final String fullName;
  final String gender;
  final String birthDate;
  final String phone;
  final String address;
  final String doctorName;
  final String notes;
  final String createdAt;

  const Patient({
    this.id,
    required this.patientNumber,
    required this.fullName,
    required this.gender,
    required this.birthDate,
    required this.phone,
    required this.address,
    required this.doctorName,
    required this.notes,
    required this.createdAt,
  });

  Patient copyWith({
    int? id,
    String? patientNumber,
    String? fullName,
    String? gender,
    String? birthDate,
    String? phone,
    String? address,
    String? doctorName,
    String? notes,
    String? createdAt,
  }) {
    return Patient(
      id: id ?? this.id,
      patientNumber:
          patientNumber ?? this.patientNumber,
      fullName: fullName ?? this.fullName,
      gender: gender ?? this.gender,
      birthDate: birthDate ?? this.birthDate,
      phone: phone ?? this.phone,
      address: address ?? this.address,
      doctorName: doctorName ?? this.doctorName,
      notes: notes ?? this.notes,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'patient_number': patientNumber,
      'full_name': fullName,
      'gender': gender,
      'birth_date': birthDate,
      'phone': phone,
      'address': address,
      'doctor_name': doctorName,
      'notes': notes,
      'created_at': createdAt,
    };
  }

  factory Patient.fromMap(
    Map<String, dynamic> map,
  ) {
    return Patient(
      id: map['id'] as int?,
      patientNumber:
          map['patient_number']?.toString() ?? '',
      fullName:
          map['full_name']?.toString() ?? '',
      gender:
          map['gender']?.toString() ?? '',
      birthDate:
          map['birth_date']?.toString() ?? '',
      phone:
          map['phone']?.toString() ?? '',
      address:
          map['address']?.toString() ?? '',
      doctorName:
          map['doctor_name']?.toString() ?? '',
      notes:
          map['notes']?.toString() ?? '',
      createdAt:
          map['created_at']?.toString() ?? '',
    );
  }
}