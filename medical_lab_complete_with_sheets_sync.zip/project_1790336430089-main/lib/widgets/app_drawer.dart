import 'package:flutter/material.dart';
import '../app/routes.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              child: Column(
                mainAxisAlignment:
                    MainAxisAlignment.center,
                children: [
                  const Icon(
                    Icons.biotech,
                    size: 55,
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'إدارة المختبر الطبي',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),

            ListTile(
              leading: const Icon(Icons.dashboard),
              title: const Text('لوحة التحكم'),
              onTap: () {
                Navigator.pushReplacementNamed(
                  context,
                  AppRoutes.dashboard,
                );
              },
            ),

            ListTile(
              leading: const Icon(Icons.people),
              title: const Text('المرضى'),
              onTap: () {
                Navigator.pushNamed(
                  context,
                  AppRoutes.patients,
                );
              },
            ),

            ListTile(
              leading: const Icon(Icons.science),
              title: const Text('التحاليل'),
              onTap: () {},
            ),

            ListTile(
              leading: const Icon(Icons.assignment),
              title: const Text('طلبات التحاليل'),
              onTap: () {},
            ),

            ListTile(
              leading: const Icon(Icons.receipt_long),
              title: const Text('الفواتير'),
              onTap: () {},
            ),

            ListTile(
              leading: const Icon(Icons.bar_chart),
              title: const Text('التقارير'),
              onTap: () {},
            ),

            const Divider(),

            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text('الإعدادات'),
              onTap: () {},
            ),

            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('تسجيل الخروج'),
              onTap: () {
                Navigator.pushReplacementNamed(
                  context,
                  AppRoutes.login,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}