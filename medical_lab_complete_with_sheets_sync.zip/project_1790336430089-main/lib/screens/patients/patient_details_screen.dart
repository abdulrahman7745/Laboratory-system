import 'package:flutter/material.dart';
import 'package:intl/intl.dart' hide TextDirection;

import '../../models/patient.dart';
import '../../repositories/patient_repository.dart';
import '../../app/routes.dart';

class PatientDetailsScreen
    extends StatefulWidget {
  final int patientId;

  const PatientDetailsScreen({
    super.key,
    required this.patientId,
  });

  @override
  State<PatientDetailsScreen> createState() =>
      _PatientDetailsScreenState();
}

class _PatientDetailsScreenState
    extends State<PatientDetailsScreen> {
  final repository = PatientRepository();

  Patient? patient;

  bool loading = true;

  @override
  void initState() {
    super.initState();
    loadPatient();
  }

  Future<void> loadPatient() async {
    final result =
        await repository.getPatient(
      widget.patientId,
    );

    if (!mounted) return;

    setState(() {
      patient = result;
      loading = false;
    });
  }

  int? calculateAge(String birthDate) {
    if (birthDate.isEmpty) return null;

    try {
      final date =
          DateTime.parse(birthDate);

      final now = DateTime.now();

      int age =
          now.year - date.year;

      if (now.month < date.month ||
          (now.month == date.month &&
              now.day < date.day)) {
        age--;
      }

      return age;
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'بيانات المريض',
          ),
        ),
        body: loading
            ? const Center(
                child:
                    CircularProgressIndicator(),
              )
            : patient == null
                ? const Center(
                    child: Text(
                      'المريض غير موجود',
                    ),
                  )
                : buildPatientView(
                    patient!,
                  ),
      ),
    );
  }

  Widget buildPatientView(
    Patient patient,
  ) {
    final age =
        calculateAge(patient.birthDate);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding:
                const EdgeInsets.all(20),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 42,
                  child: Icon(
                    patient.gender == 'أنثى'
                        ? Icons.female
                        : Icons.male,
                    size: 45,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  patient.fullName,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight:
                        FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'رقم الملف: ${patient.patientNumber}',
                ),
              ],
            ),
          ),
        ),

        const SizedBox(height: 12),

        buildInfo(
          'الجنس',
          patient.gender,
          Icons.wc,
        ),

        buildInfo(
          'العمر',
          age == null
              ? 'غير محدد'
              : '$age سنة',
          Icons.cake,
        ),

        buildInfo(
          'تاريخ الميلاد',
          patient.birthDate.isEmpty
              ? 'غير مسجل'
              : patient.birthDate,
          Icons.calendar_month,
        ),

        buildInfo(
          'رقم الهاتف',
          patient.phone.isEmpty
              ? 'غير مسجل'
              : patient.phone,
          Icons.phone,
        ),

        buildInfo(
          'العنوان',
          patient.address.isEmpty
              ? 'غير مسجل'
              : patient.address,
          Icons.location_on,
        ),

        buildInfo(
          'الطبيب المحول',
          patient.doctorName.isEmpty
              ? 'غير مسجل'
              : patient.doctorName,
          Icons.medical_services,
        ),

        buildInfo(
          'ملاحظات',
          patient.notes.isEmpty
              ? 'لا توجد ملاحظات'
              : patient.notes,
          Icons.notes,
        ),

        const SizedBox(height: 20),

        SizedBox(
          height: 52,
          child: ElevatedButton.icon(
            onPressed: () async {
              await Navigator.pushNamed(
                context,
                AppRoutes.editPatient,
                arguments: patient.id,
              );

              await loadPatient();
            },
            icon: const Icon(Icons.edit),
            label: const Text(
              'تعديل بيانات المريض',
            ),
          ),
        ),

        const SizedBox(height: 10),

        SizedBox(
          height: 52,
          child: OutlinedButton.icon(
            onPressed: () {
              // سيتم ربطها بطلب التحاليل
              // في المرحلة القادمة.
            },
            icon: const Icon(
              Icons.science,
            ),
            label: const Text(
              'إنشاء طلب تحليل',
            ),
          ),
        ),
      ],
    );
  }

  Widget buildInfo(
    String title,
    String value,
    IconData icon,
  ) {
    return Card(
      margin: const EdgeInsets.only(
        bottom: 10,
      ),
      child: ListTile(
        leading: Icon(icon),
        title: Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Text(value),
      ),
    );
  }
}