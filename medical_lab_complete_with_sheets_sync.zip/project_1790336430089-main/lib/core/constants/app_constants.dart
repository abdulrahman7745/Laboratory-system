class AppConstants {
  static const String appName = 'نظام إدارة المختبر الطبي';

  static const String databaseName = 'medical_lab.db';

  static const int databaseVersion = 1;

  static const String defaultLanguage = 'ar';

  static const String currency = 'ريال';
}