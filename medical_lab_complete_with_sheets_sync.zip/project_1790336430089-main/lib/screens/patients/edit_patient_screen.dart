import 'package:flutter/material.dart';
import 'package:intl/intl.dart' hide TextDirection;

import '../../models/patient.dart';
import '../../repositories/patient_repository.dart';

class EditPatientScreen
    extends StatefulWidget {
  final int patientId;

  const EditPatientScreen({
    super.key,
    required this.patientId,
  });

  @override
  State<EditPatientScreen> createState() =>
      _EditPatientScreenState();
}

class _EditPatientScreenState
    extends State<EditPatientScreen> {
  final repository = PatientRepository();

  final formKey =
      GlobalKey<FormState>();

  final nameController =
      TextEditingController();

  final phoneController =
      TextEditingController();

  final addressController =
      TextEditingController();

  final doctorController =
      TextEditingController();

  final notesController =
      TextEditingController();

  Patient? patient;

  String gender = 'ذكر';

  DateTime? birthDate;

  bool loading = true;

  @override
  void initState() {
    super.initState();
    loadPatient();
  }

  Future<void> loadPatient() async {
    final result =
        await repository.getPatient(
      widget.patientId,
    );

    if (!mounted) return;

    if (result != null) {
      nameController.text =
          result.fullName;

      phoneController.text =
          result.phone;

      addressController.text =
          result.address;

      doctorController.text =
          result.doctorName;

      notesController.text =
          result.notes;

      gender = result.gender;

      if (result.birthDate.isNotEmpty) {
        try {
          birthDate =
              DateTime.parse(
            result.birthDate,
          );
        } catch (_) {}
      }
    }

    setState(() {
      patient = result;
      loading = false;
    });
  }

  Future<void> selectBirthDate() async {
    final selected =
        await showDatePicker(
      context: context,
      initialDate:
          birthDate ??
              DateTime(2000),
      firstDate:
          DateTime(1900),
      lastDate: DateTime.now(),
    );

    if (selected != null) {
      setState(() {
        birthDate = selected;
      });
    }
  }

  Future<void> updatePatient() async {
    if (!formKey.currentState!
        .validate()) {
      return;
    }

    if (patient == null) return;

    final updated =
        patient!.copyWith(
      fullName:
          nameController.text.trim(),
      gender: gender,
      birthDate: birthDate == null
          ? ''
          : DateFormat(
              'yyyy-MM-dd',
            ).format(birthDate!),
      phone:
          phoneController.text.trim(),
      address:
          addressController.text.trim(),
      doctorName:
          doctorController.text.trim(),
      notes:
          notesController.text.trim(),
    );

    await repository.updatePatient(
      updated,
    );

    if (!mounted) return;

    ScaffoldMessenger.of(context)
        .showSnackBar(
      const SnackBar(
        content: Text(
          'تم تحديث بيانات المريض',
        ),
      ),
    );

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection:
          TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'تعديل بيانات المريض',
          ),
        ),
        body: loading
            ? const Center(
                child:
                    CircularProgressIndicator(),
              )
            : patient == null
                ? const Center(
                    child: Text(
                      'المريض غير موجود',
                    ),
                  )
                : Form(
                    key: formKey,
                    child: ListView(
                      padding:
                          const EdgeInsets.all(
                        16,
                      ),
                      children: [
                        TextFormField(
                          controller:
                              nameController,
                          decoration:
                              const InputDecoration(
                            labelText:
                                'اسم المريض *',
                            prefixIcon:
                                Icon(
                              Icons.person,
                            ),
                          ),
                          validator:
                              (value) {
                            if (value ==
                                    null ||
                                value
                                    .trim()
                                    .isEmpty) {
                              return 'أدخل اسم المريض';
                            }

                            return null;
                          },
                        ),

                        const SizedBox(
                          height: 15,
                        ),

                        DropdownButtonFormField<
                            String>(
                          value: gender,
                          decoration:
                              const InputDecoration(
                            labelText:
                                'الجنس',
                            prefixIcon:
                                Icon(
                              Icons.wc,
                            ),
                          ),
                          items: const [
                            DropdownMenuItem(
                              value: 'ذكر',
                              child:
                                  Text('ذكر'),
                            ),
                            DropdownMenuItem(
                              value: 'أنثى',
                              child:
                                  Text('أنثى'),
                            ),
                          ],
                          onChanged:
                              (value) {
                            if (value !=
                                null) {
                              setState(() {
                                gender =
                                    value;
                              });
                            }
                          },
                        ),

                        const SizedBox(
                          height: 15,
                        ),

                        InkWell(
                          onTap:
                              selectBirthDate,
                          child:
                              InputDecorator(
                            decoration:
                                const InputDecoration(
                              labelText:
                                  'تاريخ الميلاد',
                              prefixIcon:
                                  Icon(
                                Icons
                                    .calendar_month,
                              ),
                            ),
                            child: Text(
                              birthDate ==
                                      null
                                  ? 'اختر تاريخ الميلاد'
                                  : DateFormat(
                                      'yyyy-MM-dd',
                                    ).format(
                                      birthDate!,
                                    ),
                            ),
                          ),
                        ),

                        const SizedBox(
                          height: 15,
                        ),

                        TextFormField(
                          controller:
                              phoneController,
                          keyboardType:
                              TextInputType.phone,
                          decoration:
                              const InputDecoration(
                            labelText:
                                'رقم الهاتف',
                            prefixIcon:
                                Icon(
                              Icons.phone,
                            ),
                          ),
                        ),

                        const SizedBox(
                          height: 15,
                        ),

                        TextFormField(
                          controller:
                              addressController,
                          decoration:
                              const InputDecoration(
                            labelText:
                                'العنوان',
                            prefixIcon:
                                Icon(
                              Icons
                                  .location_on,
                            ),
                          ),
                        ),

                        const SizedBox(
                          height: 15,
                        ),

                        TextFormField(
                          controller:
                              doctorController,
                          decoration:
                              const InputDecoration(
                            labelText:
                                'الطبيب المحول',
                            prefixIcon:
                                Icon(
                              Icons
                                  .medical_services,
                            ),
                          ),
                        ),

                        const SizedBox(
                          height: 15,
                        ),

                        TextFormField(
                          controller:
                              notesController,
                          maxLines: 4,
                          decoration:
                              const InputDecoration(
                            labelText:
                                'ملاحظات',
                            prefixIcon:
                                Icon(
                              Icons.notes,
                            ),
                          ),
                        ),

                        const SizedBox(
                          height: 25,
                        ),

                        SizedBox(
                          height: 52,
                          child:
                              ElevatedButton
                                  .icon(
                            onPressed:
                                updatePatient,
                            icon:
                                const Icon(
                              Icons.save,
                            ),
                            label:
                                const Text(
                              'حفظ التعديلات',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
      ),
    );
  }

  @override
  void dispose() {
    nameController.dispose();
    phoneController.dispose();
    addressController.dispose();
    doctorController.dispose();
    notesController.dispose();

    super.dispose();
  }
}