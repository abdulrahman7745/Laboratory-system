import 'package:flutter/material.dart';

import '../../widgets/app_drawer.dart';
import '../../widgets/dashboard_card.dart';
import '../../app/routes.dart';
import '../../repositories/patient_repository.dart';
import '../../services/sheets_sync_service.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({
    super.key,
  });

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final patientRepository = PatientRepository();
  final sheetsSyncService = SheetsSyncService();

  int patientsCount = 0;
  bool isSyncing = false;

  @override
  void initState() {
    super.initState();
    loadStatistics();
  }

  Future<void> loadStatistics() async {
    final count = await patientRepository.getPatientsCount();

    if (!mounted) return;

    setState(() {
      patientsCount = count;
    });
  }

  Future<void> openPatients() async {
    await Navigator.pushNamed(
      context,
      AppRoutes.patients,
    );

    await loadStatistics();
  }

  Future<void> syncWithSheets() async {
    setState(() {
      isSyncing = true;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('جارٍ المزامنة السحابية مع Google Sheets...'),
        duration: Duration(seconds: 2),
      ),
    );

    final success = await sheetsSyncService.syncAllPatients();

    if (!mounted) return;

    setState(() {
      isSyncing = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          success
              ? 'تمت المزامنة السحابية مع Google Sheets بنجاح!'
              : 'تعذر الاتصال بخادم Google Apps Script.',
        ),
        backgroundColor: success ? Colors.green : Colors.red,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'لوحة التحكم',
          ),
          actions: [
            IconButton(
              tooltip: 'مزامنة سحابية مع Google Sheets',
              icon: isSyncing
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.cloud_sync),
              onPressed: isSyncing ? null : syncWithSheets,
            ),
          ],
        ),
        drawer: const AppDrawer(),
        body: RefreshIndicator(
          onRefresh: loadStatistics,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const SizedBox(height: 10),

              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.45,
                children: [
                  DashboardCard(
                    title: 'المرضى',
                    value: '$patientsCount',
                    icon: Icons.people,
                    onTap: openPatients,
                  ),

                  const DashboardCard(
                    title: 'طلبات اليوم',
                    value: '0',
                    icon: Icons.assignment,
                  ),

                  const DashboardCard(
                    title: 'التحاليل',
                    value: '0',
                    icon: Icons.science,
                  ),

                  const DashboardCard(
                    title: 'الإيرادات',
                    value: '0',
                    icon: Icons.payments,
                  ),
                ],
              ),

              const SizedBox(
                height: 25,
              ),

              Card(
                child: Padding(
                  padding: const EdgeInsets.all(
                    20,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'إجراءات سريعة',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const SizedBox(
                        height: 15,
                      ),

                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: () async {
                            await Navigator.pushNamed(
                              context,
                              AppRoutes.addPatient,
                            );

                            await loadStatistics();
                          },
                          icon: const Icon(
                            Icons.person_add,
                          ),
                          label: const Text(
                            'تسجيل مريض جديد',
                          ),
                        ),
                      ),

                      const SizedBox(
                        height: 10,
                      ),

                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: () {
                            // سيضاف في المرحلة القادمة.
                          },
                          icon: const Icon(
                            Icons.science,
                          ),
                          label: const Text(
                            'إنشاء طلب تحليل',
                          ),
                        ),
                      ),

                      const SizedBox(
                        height: 10,
                      ),

                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: isSyncing ? null : syncWithSheets,
                          icon: const Icon(
                            Icons.cloud_upload,
                          ),
                          label: const Text(
                            'مزامنة البيانات مع Google Sheets',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}