import '../core/database/database_helper.dart';
import '../models/patient.dart';

class PatientRepository {
  final DatabaseHelper _databaseHelper =
      DatabaseHelper.instance;

  Future<int> insertPatient(
    Patient patient,
  ) async {
    final db = await _databaseHelper.database;

    return db.insert(
      'patients',
      patient.toMap(),
    );
  }

  Future<List<Patient>> getPatients() async {
    final db = await _databaseHelper.database;

    final result = await db.query(
      'patients',
      orderBy: 'id DESC',
    );

    return result
        .map(Patient.fromMap)
        .toList();
  }

  Future<Patient?> getPatient(
    int id,
  ) async {
    final db = await _databaseHelper.database;

    final result = await db.query(
      'patients',
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );

    if (result.isEmpty) {
      return null;
    }

    return Patient.fromMap(result.first);
  }

  Future<List<Patient>> searchPatients(
    String query,
  ) async {
    final db = await _databaseHelper.database;

    final text = query.trim();

    if (text.isEmpty) {
      return getPatients();
    }

    final result = await db.query(
      'patients',
      where: '''
        full_name LIKE ?
        OR patient_number LIKE ?
        OR phone LIKE ?
        OR doctor_name LIKE ?
      ''',
      whereArgs: [
        '%$text%',
        '%$text%',
        '%$text%',
        '%$text%',
      ],
      orderBy: 'id DESC',
    );

    return result
        .map(Patient.fromMap)
        .toList();
  }

  Future<int> updatePatient(
    Patient patient,
  ) async {
    if (patient.id == null) {
      throw Exception(
        'Patient ID is required',
      );
    }

    final db = await _databaseHelper.database;

    return db.update(
      'patients',
      patient.toMap(),
      where: 'id = ?',
      whereArgs: [patient.id],
    );
  }

  Future<int> deletePatient(
    int id,
  ) async {
    final db = await _databaseHelper.database;

    return db.delete(
      'patients',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> getPatientsCount() async {
    final db = await _databaseHelper.database;

    final result = await db.rawQuery(
      'SELECT COUNT(*) AS count FROM patients',
    );

    return SqfliteResultParser.count(result);
  }
}

class SqfliteResultParser {
  static int count(
    List<Map<String, dynamic>> result,
  ) {
    if (result.isEmpty) {
      return 0;
    }

    return (result.first['count'] as num?)?.toInt() ?? 0;
  }
}