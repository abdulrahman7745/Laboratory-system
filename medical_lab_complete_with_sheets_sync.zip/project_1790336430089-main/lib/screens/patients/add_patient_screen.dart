import 'package:flutter/material.dart';
import 'package:intl/intl.dart' hide TextDirection;

import '../../models/patient.dart';
import '../../repositories/patient_repository.dart';

class AddPatientScreen extends StatefulWidget {
  const AddPatientScreen({super.key});

  @override
  State<AddPatientScreen> createState() =>
      _AddPatientScreenState();
}

class _AddPatientScreenState
    extends State<AddPatientScreen> {
  final formKey = GlobalKey<FormState>();

  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final addressController = TextEditingController();
  final doctorController = TextEditingController();
  final notesController = TextEditingController();

  final PatientRepository repository =
      PatientRepository();

  String gender = 'ذكر';

  DateTime? birthDate;

  Future<void> selectBirthDate() async {
    final selected = await showDatePicker(
      context: context,
      initialDate: DateTime(2000),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
      locale: const Locale('ar'),
    );

    if (selected != null) {
      setState(() {
        birthDate = selected;
      });
    }
  }

  String generatePatientNumber() {
    final timestamp =
        DateTime.now().millisecondsSinceEpoch;

    return 'P${timestamp.toString().substring(5)}';
  }

  Future<void> savePatient() async {
    if (!formKey.currentState!.validate()) {
      return;
    }

    final patient = Patient(
      patientNumber: generatePatientNumber(),
      fullName: nameController.text.trim(),
      gender: gender,
      birthDate: birthDate == null
          ? ''
          : DateFormat('yyyy-MM-dd')
              .format(birthDate!),
      phone: phoneController.text.trim(),
      address: addressController.text.trim(),
      doctorName: doctorController.text.trim(),
      notes: notesController.text.trim(),
      createdAt: DateTime.now().toIso8601String(),
    );

    await repository.insertPatient(patient);

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'تم تسجيل المريض بنجاح',
        ),
      ),
    );

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('تسجيل مريض جديد'),
        ),
        body: Form(
          key: formKey,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              TextFormField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: 'اسم المريض *',
                  prefixIcon: Icon(Icons.person),
                ),
                validator: (value) {
                  if (value == null ||
                      value.trim().isEmpty) {
                    return 'أدخل اسم المريض';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 15),

              DropdownButtonFormField<String>(
                value: gender,
                decoration: const InputDecoration(
                  labelText: 'الجنس',
                  prefixIcon: Icon(Icons.wc),
                ),
                items: const [
                  DropdownMenuItem(
                    value: 'ذكر',
                    child: Text('ذكر'),
                  ),
                  DropdownMenuItem(
                    value: 'أنثى',
                    child: Text('أنثى'),
                  ),
                ],
                onChanged: (value) {
                  if (value != null) {
                    setState(() {
                      gender = value;
                    });
                  }
                },
              ),

              const SizedBox(height: 15),

              InkWell(
                onTap: selectBirthDate,
                child: InputDecorator(
                  decoration: const InputDecoration(
                    labelText: 'تاريخ الميلاد',
                    prefixIcon:
                        Icon(Icons.calendar_month),
                  ),
                  child: Text(
                    birthDate == null
                        ? 'اختر تاريخ الميلاد'
                        : DateFormat('yyyy-MM-dd')
                            .format(birthDate!),
                  ),
                ),
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller: phoneController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'رقم الهاتف',
                  prefixIcon: Icon(Icons.phone),
                ),
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller: addressController,
                decoration: const InputDecoration(
                  labelText: 'العنوان',
                  prefixIcon: Icon(Icons.location_on),
                ),
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller: doctorController,
                decoration: const InputDecoration(
                  labelText: 'الطبيب المحول',
                  prefixIcon: Icon(Icons.medical_services),
                ),
              ),

              const SizedBox(height: 15),

              TextFormField(
                controller: notesController,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'ملاحظات',
                  prefixIcon: Icon(Icons.notes),
                ),
              ),

              const SizedBox(height: 25),

              SizedBox(
                height: 52,
                child: ElevatedButton.icon(
                  onPressed: savePatient,
                  icon: const Icon(Icons.save),
                  label: const Text(
                    'حفظ بيانات المريض',
                    style: TextStyle(
                      fontSize: 17,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    nameController.dispose();
    phoneController.dispose();
    addressController.dispose();
    doctorController.dispose();
    notesController.dispose();

    super.dispose();
  }
}