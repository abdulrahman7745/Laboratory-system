package com.labort.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
