import 'package:flutter/material.dart';

import '../../app/routes.dart';
import '../../models/patient.dart';
import '../../repositories/patient_repository.dart';
import '../../widgets/patient_card.dart';

class PatientsScreen extends StatefulWidget {
  const PatientsScreen({super.key});

  @override
  State<PatientsScreen> createState() =>
      _PatientsScreenState();
}

class _PatientsScreenState
    extends State<PatientsScreen> {
  final repository = PatientRepository();

  final searchController =
      TextEditingController();

  List<Patient> patients = [];

  bool loading = true;

  @override
  void initState() {
    super.initState();
    loadPatients();
  }

  Future<void> loadPatients() async {
    setState(() {
      loading = true;
    });

    final result =
        await repository.getPatients();

    if (!mounted) return;

    setState(() {
      patients = result;
      loading = false;
    });
  }

  Future<void> search() async {
    final result =
        await repository.searchPatients(
      searchController.text,
    );

    if (!mounted) return;

    setState(() {
      patients = result;
    });
  }

  Future<void> deletePatient(
    Patient patient,
  ) async {
    if (patient.id == null) return;

    final confirmed =
        await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            'تأكيد الحذف',
          ),
          content: Text(
            'هل تريد حذف المريض ${patient.fullName}؟',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(
                  context,
                  false,
                );
              },
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.pop(
                  context,
                  true,
                );
              },
              child: const Text('حذف'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) {
      return;
    }

    await repository.deletePatient(
      patient.id!,
    );

    await loadPatients();
  }

  Future<void> openAddPatient() async {
    await Navigator.pushNamed(
      context,
      AppRoutes.addPatient,
    );

    await loadPatients();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'إدارة المرضى',
          ),
        ),
        floatingActionButton:
            FloatingActionButton.extended(
          onPressed: openAddPatient,
          icon: const Icon(
            Icons.person_add,
          ),
          label: const Text(
            'إضافة مريض',
          ),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: TextField(
                controller:
                    searchController,
                onChanged: (_) {
                  search();
                },
                decoration:
                    InputDecoration(
                  hintText:
                      'ابحث عن مريض...',
                  prefixIcon:
                      const Icon(
                    Icons.search,
                  ),
                  suffixIcon:
                      IconButton(
                    onPressed: () {
                      searchController
                          .clear();
                      loadPatients();
                    },
                    icon: const Icon(
                      Icons.clear,
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: loading
                  ? const Center(
                      child:
                          CircularProgressIndicator(),
                    )
                  : patients.isEmpty
                      ? const Center(
                          child: Column(
                            mainAxisSize:
                                MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.people_outline,
                                size: 70,
                              ),
                              SizedBox(height: 12),
                              Text(
                                'لا يوجد مرضى',
                                style:
                                    TextStyle(
                                  fontSize: 18,
                                ),
                              ),
                            ],
                          ),
                        )
                      : RefreshIndicator(
                          onRefresh:
                              loadPatients,
                          child:
                              ListView.builder(
                            padding:
                                const EdgeInsets
                                    .fromLTRB(
                              16,
                              0,
                              16,
                              100,
                            ),
                            itemCount:
                                patients.length,
                            itemBuilder:
                                (context, index) {
                              final patient =
                                  patients[index];

                              return PatientCard(
                                patient:
                                    patient,
                                onTap: () async {
                                  await Navigator
                                      .pushNamed(
                                    context,
                                    AppRoutes
                                        .patientDetails,
                                    arguments:
                                        patient.id,
                                  );

                                  await loadPatients();
                                },
                                onDelete: () {
                                  deletePatient(
                                    patient,
                                  );
                                },
                              );
                            },
                          ),
                        ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }
}